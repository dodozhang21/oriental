Thank you for choosing oriental Theme.

Version History:

version 1.1.1 � Recoded to use relative positioning instead of float.
version 1.1.2 � Fixed IE 6 issue brought up http://wordpress.org/support/topic/208400 and the random post issue brought up http://wordpress.org/support/topic/218342
version 1.2.0 � Making the theme compatible with wp 2.7. And sorry I no longer wish to support IE 6. If this theme doesn�t look good in IE 6, use a different one. And seriously everyone need to move off the evil IE 6.
version 1.2.1 � Made the theme a bit more backward compatible.
version 1.3.0 � Made compatible with wordpress version 3.5.1. Fixed some bugs viewed under the latest versions of the browers. Added responsive web styling. Added support for wordpress 3 menu.
version 1.3.10 - Updated screenshot and the sidebar background image, fixed site title
version 1.3.11 - Makes the theme translation ready
version 1.3.12 - Revamp on the main menu and comment styles. Now requires WP 3.8+ as it's dependent on dashicons.

--------------------------------------------------------------------------------
For support:
--------------------------------------------------------------------------------
visit http://pure-essence.net/2008/09/19/wordpress-theme-oriental/


--------------------------------------------------------------------------------
Notes:
--------------------------------------------------------------------------------
Requires WP 3.8+
Long menu is not supported by the top menu. Please do not put too many items in your top menu or you will run into layout issue with the top menu.


--------------------------------------------------------------------------------
 Licenses:
--------------------------------------------------------------------------------
Oriental WordPress Theme, copyright 2013 Ying Zhang
Oriental is distributed under the terms of the GNU GPLv2. See license.txt for further details.

The resources used in oriental theme are all GPL-compatible:

== Bundled Resources: Javascript ==

* js/*.js: http://www.opensource.org/licenses/mit-license.php


== Bundled Resources: Images ==

* images/*.*: http://www.gnu.org/licenses/gpl-2.0.html


== Fonts ==

Google web fonts are licensed under open source licenses
https://developers.google.com/webfonts/faq


--------------------------------------------------------------------------------
